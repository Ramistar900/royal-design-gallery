# ROYAL Android Icons v2

This package extends the initial ROYAL Design icon set with Android-ready VectorDrawable XML resources.

## Contents
- `svg/`: 21 editable/scalable SVG source icons for import into Figma.
- `android/res/drawable/`: 21 Android VectorDrawable XML files named `royal_<icon>.xml`.
- All icons use a 24 × 24 viewport, gold outline `#D6B25E`, stroke width 1.8, rounded caps and joins.

## Android integration
Copy the XML files from `android/res/drawable/` into the Android module's `app/src/main/res/drawable/` folder. Reference them as `R.drawable.royal_apps`, `R.drawable.royal_wifi`, etc.

Example:
```xml
<ImageView
    android:layout_width="24dp"
    android:layout_height="24dp"
    android:contentDescription="@string/icon_description"
    app:srcCompat="@drawable/royal_wifi" />
```
Ensure the layout root declares `xmlns:app="http://schemas.android.com/apk/res-auto"` if using `app:srcCompat`.

## Important
These are original ROYAL icons inspired by contemporary Android/Material visual conventions; they are not official Google Material Symbols assets. No Android application repository was modified and no app build was run.
